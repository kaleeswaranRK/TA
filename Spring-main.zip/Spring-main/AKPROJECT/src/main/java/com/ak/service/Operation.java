package com.ak.service;

import java.io.IOException;

public interface Operation {
	String add(long a, long b);

	String sub(long a, long b);

	String mul(long a, long b);

	String div(long a, long b);




}
